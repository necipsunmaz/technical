# -*- coding: utf-8 -*-
from django.shortcuts import render

from servisapp.models import *


def index(request):
    return render(request, 'index.html', {})

def sayfayiyazdir(request, idsi):

        FormDurumu = ServisForm.objects.get(id = idsi)

        FormBilgileri = Urun.objects.filter(ServisForm__id = idsi)

        return render(request, 'yazdir.html', {'FormBilgileri': FormBilgileri,'FormDurumu':FormDurumu})
