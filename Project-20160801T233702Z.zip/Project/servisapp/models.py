# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import datetime
from django.conf import settings
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
import random, string


class Teknisyen(models.Model):
    Aktif = models.BooleanField(default=True)
    AdSoyad = models.CharField(u'Adı Soyadı', max_length=250)
    KayitTarihi = models.DateField(u'Kayıt Tarihi', default=timezone.now)

    def __unicode__(self):
        return self.AdSoyad
    class Meta:
        verbose_name_plural = u'Teknisyenler'
        verbose_name = u'Teknisyen'

    def Yazdir(self):
        return '<a href="/yazdir/%s" target="_blank">Yazdır</a>' % self.id
    Yazdir.short_description = u'Yazdir'
    Yazdir.allow_tags = True

class Musteri(models.Model):
    Aktif = models.BooleanField(default=True)
    Kodu = models.CharField(u'Müşteri Kodu',
    default=''.join(random.choice(string.digits)for x in range(8)),max_length=250)
    Unvan = models.CharField(u'Ticari Ünvan', max_length=250)
    Yetkili = models.CharField(u'Yetkili Adı Soyadı', max_length=250)
    Telefon = models.CharField(u'Telefon', max_length=13, blank=True)
    KayitTarihi = models.DateField(u'Kayit Tarihi', default=timezone.now)

    def __unicode__(self):
        return "Müşteri Kodu: %s -Adı: %s" %(self.Kodu, self.Yetkili)

    def AramaYap (self):
        if self.Telefon:
            return '<a href="tel: %s" target="_blank">Numarayı Ara</a>' % self.Telefon
        else:
            return  'Telefon No kayıtlı değil.'
    AramaYap.shot_description = u'Ara'
    AramaYap.allow_tags = True

    class Meta:
        verbose_name_plural = u'Müşteriler'
        verbose_name = u'Müşteri'

class UserProfile(models.Model):
    user = models.OneToOneField(User)

class Durum(models.Model):
    Durumu = models.CharField(u'Durum', max_length=30, help_text='''Metin alanının altında
kayıt girerken yardımcı olabilecek konuları anlatan kısa bir açıklama
yazabilirsiniz.''')
    def __unicode__(self):
        return self.Durumu
    class Meta:
        verbose_name_plural = u'Durumlar'
        verbose_name = u'Durum'

class Aksesuar(models.Model):
    Adi = models.CharField(u'Adı', max_length=30, help_text='''Ürün ile birlikte gönderilen tüm
    aksesuarlar. Örneğin: Kulaklık,Batarya''')
    def __unicode__(self):
        return self.Adi
    class Meta:
        verbose_name_plural = u'Aksesuarlar'
        verbose_name = u'Aksesuar'

class ServisForm(models.Model):
    Musteri = models.ForeignKey(Musteri)
    TeslimEden = models.CharField(u'Teslim Eden', max_length=250)
    TeslimAlan = models.ForeignKey(Teknisyen,
    default = int(Teknisyen.objects.get(id=1).id))
    FormNo = models.CharField(u'Form No', max_length=8,
    default=''.join(random.choice(string.digits)for x in range(8)))
    KayitTarihi = models.DateField(u'Kayıt Tarihi', default=timezone.now)

    def __unicode__(self):
        return self.FormNo

    class Meta:
        verbose_name_plural = u'Servis Formları'
        verbose_name = u'Servis Formu'

    def Yazdir (self):
        return '<a href="/yazdir/%s" target="_blank">Yazdır</a>' % self.id
    Yazdir.short_description = u'Yazdır'
    Yazdir.allow_tags = True

class Urun(models.Model):
    ServisForm = models.ForeignKey(ServisForm)
    Cins = models.CharField(u'Cins', max_length=50)
    Marka = models.CharField(u'Marka', max_length=50)
    Model = models.CharField(u'Model', max_length=50)
    SeriNo= models.CharField(u'Seri No', max_length=250)
    GarantiBitis = models.DateField(u'Garanti Bitişi', default=timezone.now)
    Sikayet = models.TextField(u'Şikayet')
    Aksesuar = models.ManyToManyField(Aksesuar, blank=True)
    Durum = models.ForeignKey(Durum)
    Not = models.TextField(u'Yapılan İşlemler', blank=True)

    def __unicode__(self):
        return "%s %s %s" %(self.Cins, self.Marka, self.Model)

    class Meta:
        verbose_name_plural = u'Ürünler'
        verbose_name = u'Ürün'