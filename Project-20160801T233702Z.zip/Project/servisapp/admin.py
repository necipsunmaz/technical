# -*- coding: utf-8 -*-
from django.contrib import admin
from servisapp.models import *


class TeknisyenAdmin(admin.ModelAdmin):
    list_display = ('Aktif', 'AdSoyad', 'Yazdir')
    list_filter = ('Aktif', 'AdSoyad')
    search_fields = ['AdSoyad']
    list_per_page = 20
    exclude = ['KayitTarihi']
    list_display_links = ('AdSoyad',)

admin.site.register(Teknisyen, TeknisyenAdmin)


def SecilileriGuncelle(modeladmin, request, queryset):
    print queryset
    for k in queryset:
        k.Yetkili = k.Yetkili + '___'
        k.save()
    return ""


SecilileriGuncelle.short_description = u'Seçilenleri Güncelle'


class MusteriAdmin(admin.ModelAdmin):
    list_display = ('Kodu', 'Unvan', 'Yetkili', 'Aktif', 'AramaYap')
    list_per_page = 80
    exclude = ['KayitTarihi']
    search_fields = ['Yetkili', 'Unvan']
    list_display_links = ('Unvan', 'Yetkili',)
    actions = (SecilileriGuncelle,)
    actions_on_bottom = True
    actions_on_top = True
    def __unicode__(self):
        return "Müşteri Kodu: %s - Adı: %s" % (self.Kodu, self.Yetkili)

admin.site.register(Musteri, MusteriAdmin)

class DurumAdmin(admin.ModelAdmin):
    list_display = ('Durumu',)
    list_per_page = 20
    search_fields = ['Durum']
    list_display_links = ('Durumu',)
admin.site.register(Durum, DurumAdmin)

class AksesuarAdmin(admin.ModelAdmin):
    list_display = ('Adi',)
    list_per_page = 5
admin.site.register(Aksesuar, AksesuarAdmin)

class UrunInline(admin.StackedInline):
    model = Urun
    extra = 0
    max_num = 6

class ServisFormAdmin(admin.ModelAdmin):
    inlines = [UrunInline,]
    list_display = ('FormNo', 'Musteri', 'TeslimEden', 'TeslimAlan', 'KayitTarihi', 'Yazdir')
    list_per_page = 50
    date_hierarchy = 'KayitTarihi'
    search_fields = ('FormNo', 'Musteri__Yetkili', 'Musteri__Telefon')
    exclude = ['KayitTarihi']

    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == 'TeslimAlan':
            kwargs['queryset'] = Teknisyen.objects.filter(Aktif=True)
        if db_field.name == 'Musteri':
            kwargs['queryset'] = Musteri.objects.filter(Aktif=True)
        return super(ServisFormAdmin, self).formfield_for_foreignkey(db_field,request,**kwargs)

admin.site.register(ServisForm, ServisFormAdmin)