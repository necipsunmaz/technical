# -*- coding: utf-8 -*-
default_app_config = 'servisapp.apps.ServisappConfig'